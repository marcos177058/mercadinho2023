import tkinter as tk
from tkinter import messagebox
import sqlite3

# Conectando ao banco de dados
conn = sqlite3.connect('gerenciamento_fornecedores.db')
cursor = conn.cursor()

# Criando tabela de fornecedores
cursor.execute('''
    CREATE TABLE IF NOT EXISTS fornecedores (
        id INTEGER PRIMARY KEY,
        nome TEXT,
        endereco TEXT,
        contato TEXT
    )
''')

# Função para cadastrar um fornecedor
def cadastrar_fornecedor():
    nome = nome_entry.get()
    endereco = endereco_entry.get()
    contato = contato_entry.get()

    cursor.execute('INSERT INTO fornecedores (nome, endereco, contato) VALUES (?, ?, ?)', (nome, endereco, contato))
    conn.commit()

    messagebox.showinfo("Sucesso", "Fornecedor cadastrado com sucesso!")

# Criando a janela principal
root = tk.Tk()
root.title("Gerenciamento de Fornecedores")

# Criando os widgets da interface
nome_label = tk.Label(root, text="Nome:")
nome_label.pack()
nome_entry = tk.Entry(root)
nome_entry.pack()

endereco_label = tk.Label(root, text="Endereço:")
endereco_label.pack()
endereco_entry = tk.Entry(root)
endereco_entry.pack()

contato_label = tk.Label(root, text="Contato:")
contato_label.pack()
contato_entry = tk.Entry(root)
contato_entry.pack()

cadastrar_button = tk.Button(root, text="Cadastrar", command=cadastrar_fornecedor)
cadastrar_button.pack()

# Executando a interface
root.mainloop()

# Fechando a conexão com o banco de dados
conn.close()
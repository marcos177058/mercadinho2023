import sqlite3

# Conectando ao banco de dados
conn = sqlite3.connect('gerenciamento_fornecedores.db')
cursor = conn.cursor()

# Criando tabela de fornecedores
cursor.execute('''
    CREATE TABLE IF NOT EXISTS fornecedores (
        id INTEGER PRIMARY KEY,
        nome TEXT,
        endereco TEXT,
        contato TEXT
    )
''')

# Criando tabela de produtos
cursor.execute('''
    CREATE TABLE IF NOT EXISTS produtos (
        id INTEGER PRIMARY KEY,
        nome TEXT,
        preco REAL,
        fornecedor_id INTEGER,
        FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id)
    )
''')

# Função para cadastrar um fornecedor
def cadastrar_fornecedor(nome, endereco, contato):
    cursor.execute('INSERT INTO fornecedores (nome, endereco, contato) VALUES (?, ?, ?)', (nome, endereco, contato))
    conn.commit()

# Função para cadastrar um produto
def cadastrar_produto(nome, preco, fornecedor_id):
    cursor.execute('INSERT INTO produtos (nome, preco, fornecedor_id) VALUES (?, ?, ?)', (nome, preco, fornecedor_id))
    conn.commit()

# Função para editar um fornecedor
def editar_fornecedor(fornecedor_id, nome, endereco, contato):
    cursor.execute('UPDATE fornecedores SET nome=?, endereco=?, contato=? WHERE id=?', (nome, endereco, contato, fornecedor_id))
    conn.commit()

# Função para remover um fornecedor
def remover_fornecedor(fornecedor_id):
    cursor.execute('DELETE FROM fornecedores WHERE id=?', (fornecedor_id,))
    conn.commit()

# Exemplo de uso das funções
cadastrar_fornecedor('Fornecedor A', 'Endereço A', 'Contato A')
cadastrar_fornecedor('Fornecedor B', 'Endereço B', 'Contato B')

cadastrar_produto('Produto 1', 10.99, 1)
cadastrar_produto('Produto 2', 5.99, 2)

editar_fornecedor(1, 'Novo Nome', 'Novo Endereço', 'Novo Contato')

remover_fornecedor(2)

# Consulta de fornecedores e produtos
cursor.execute('SELECT * FROM fornecedores')
fornecedores = cursor.fetchall()
print('Fornecedores:')
for fornecedor in fornecedores:
    print(fornecedor)

cursor.execute('SELECT * FROM produtos')
produtos = cursor.fetchall()
print('Produtos:')
for produto in produtos:
    print(produto)

# Fechando a conexão com o banco de dados
conn.close()

import tkinter as tk
from tkinter import messagebox

# Função para cadastrar um fornecedor
def cadastrar_fornecedor():
    nome = nome_entry.get()
    endereco = endereco_entry.get()
    contato = contato_entry.get()

    # Aqui você pode adicionar a lógica para cadastrar o fornecedor no banco de dados

    messagebox.showinfo("Sucesso", "Fornecedor cadastrado com sucesso!")

# Criando a janela principal
root = tk.Tk()
root.title("Gerenciamento de Fornecedores")

# Criando os widgets da interface
nome_label = tk.Label(root, text="Nome:")
nome_label.pack()
nome_entry = tk.Entry(root)
nome_entry.pack()

endereco_label = tk.Label(root, text="Endereço:")
endereco_label.pack()
endereco_entry = tk.Entry(root)
endereco_entry.pack()

contato_label = tk.Label(root, text="Contato:")
contato_label.pack()
contato_entry = tk.Entry(root)
contato_entry.pack()

cadastrar_button = tk.Button(root, text="Cadastrar", command=cadastrar_fornecedor)
cadastrar_button.pack()

# Executando a interface
root.mainloop()

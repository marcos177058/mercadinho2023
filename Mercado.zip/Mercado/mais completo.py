import tkinter as tk
from tkinter import messagebox
import sqlite3

# Conectando ao banco de dados
conn = sqlite3.connect('gerenciamento_fornecedores.db')
cursor = conn.cursor()

# Criando tabela de fornecedores
cursor.execute('''
    CREATE TABLE IF NOT EXISTS fornecedores (
        id INTEGER PRIMARY KEY,
        nome TEXT,
        endereco TEXT,
        contato TEXT
    )
''')

# Função para cadastrar um fornecedor
def cadastrar_fornecedor():
    nome = nome_entry.get()
    endereco = endereco_entry.get()
    contato = contato_entry.get()

    cursor.execute('INSERT INTO fornecedores (nome, endereco, contato) VALUES (?, ?, ?)', (nome, endereco, contato))
    conn.commit()

    messagebox.showinfo("Sucesso", "Fornecedor cadastrado com sucesso!")

# Função para abrir uma nova janela com a lista de fornecedores
def ver_fornecedores():
    fornecedores_window = tk.Toplevel(root)
    fornecedores_window.title("Fornecedores Cadastrados")

    # Criando um widget de lista para exibir os fornecedores
    fornecedores_listbox = tk.Listbox(fornecedores_window, width=100)
    fornecedores_listbox.pack()

    # Consulta ao banco de dados para obter os fornecedores cadastrados
    cursor.execute('SELECT * FROM fornecedores')
    fornecedores = cursor.fetchall()

    # Adicionando os fornecedores à lista
    for fornecedor in fornecedores:
        fornecedores_listbox.insert(tk.END, f"ID: {fornecedor[0]}, Nome: {fornecedor[1]}, Endereço: {fornecedor[2]}, Contato: {fornecedor[3]}")

# Função para abrir a tela de cadastro de produtos
def abrir_cadastro_produtos():
    produtos_window = tk.Toplevel(root)
    produtos_window.title("Cadastro de Produtos")

    # Adicione a lógica e os elementos da tela de cadastro de produtos aqui

    # Botão para voltar à tela principal
    voltar_button = tk.Button(produtos_window, text="Voltar", command=produtos_window.destroy)
    voltar_button.pack()

# Função para abrir a tela de visualização de estoque
def abrir_visualizacao_estoque():
    estoque_window = tk.Toplevel(root)
    estoque_window.title("Visualização de Estoque")

    # Adicione a lógica e os elementos da tela de visualização de estoque aqui

    # Botão para voltar à tela principal
    voltar_button = tk.Button(estoque_window, text="Voltar", command=estoque_window.destroy)
    voltar_button.pack()

# Função para abrir a tela de criação de estoque
def abrir_criacao_estoque():
    criacao_estoque_window = tk.Toplevel(root)
    criacao_estoque_window.title("Criação de Estoque")

    # Adicione a lógica e os elementos da tela de criação de estoque aqui

    # Botão para voltar à tela principal
    voltar_button = tk.Button(criacao_estoque_window, text="Voltar", command=criacao_estoque_window.destroy)
    voltar_button.pack()

# Criando a janela principal
root = tk.Tk()
root.title("Tela Principal")
root.geometry("800x600")

# Botão para acessar o gerenciamento de fornecedores
fornecedores_button = tk.Button(root, text="Gerenciar Fornecedores", command=ver_fornecedores)
fornecedores_button.pack()

# Botão para acessar o cadastro de produtos
cadastro_produtos_button = tk.Button(root, text="Cadastro de Produtos", command=abrir_cadastro_produtos)
cadastro_produtos_button.pack()

# Botão para acessar a visualização de estoque
visualizacao_estoque_button = tk.Button(root, text="Visualização de Estoque", command=abrir_visualizacao_estoque)
visualizacao_estoque_button.pack()

# Botão para acessar a criação de estoque
criacao_estoque_button = tk.Button(root, text="Criação de Estoque", command=abrir_criacao_estoque)
criacao_estoque_button.pack()

# Executando a interface
root.mainloop()

# Fechando a conexão com o banco de dados
conn.close()